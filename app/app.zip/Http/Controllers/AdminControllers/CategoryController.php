<?php

namespace App\Http\Controllers\AdminControllers;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Shared\BaseController;
use App\Models\Categories;
use Illuminate\Http\Request;

class CategoryController extends BaseController
{
    public function index(){
        $categories=Categories::where('deleted_at',null)->get();
        return view('admin.Pages.Category.categories',compact('categories'));
    }
}
