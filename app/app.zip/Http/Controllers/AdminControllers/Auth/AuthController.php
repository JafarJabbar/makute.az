<?php

namespace App\Http\Controllers\AdminControllers\Auth;

use App\Http\Controllers\Shared\BaseController;
use App\Models\Users;
use Illuminate\Http\Request;
use Cache;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends BaseController
{
    public function login(){
        if (!Cache::get('token')){
            return view('admin.login');
        }else{
            return redirect()->route('admin.dashboard');
        }
    }
    public function start(Request $request){
        $user=Users::where([['email',$request->post('email')],['password',md5($request->post('password'))]])->first();
        if($user){
            Cache::put('token',csrf_token());
            Cache::put('username',$user->username);
            Cache::put('id',$user->id);
            return redirect()->route('admin.dashboard');
        }else{
            return redirect()->route('auth.login');
        }
    }
}
