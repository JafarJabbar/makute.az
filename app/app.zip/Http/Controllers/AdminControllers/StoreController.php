<?php

namespace App\Http\Controllers\AdminControllers;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Shared\BaseController;
use App\Models\Stores;
use Illuminate\Http\Request;

class StoreController extends BaseController
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index(){
        $stores=Stores::where('deleted_at',null)->get();
        return view('admin.Pages.Strores.stores',compact('stores'));

    }
}
