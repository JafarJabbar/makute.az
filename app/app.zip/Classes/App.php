<?php
class App{
    public function imageUpload($params)
    {
        $oldPhoto = @$params['path'] . '/' . @$params['filename'];
        if (file_exists($oldPhoto)):
            @unlink($oldPhoto);
        endif;
        $photo = _ImageUpload($params['file'], $params['path']);
        if (@$params['thumbnail'])
            $photo = $photo->thumbnail($params['thumbnail']);
        if (@$params['filetype'])
            $photo = $photo->filetype($params['filetype']);
        $photo = $photo->save();
        return $photo;
    }
    function _App()
    {
        return new App();
    }

}
